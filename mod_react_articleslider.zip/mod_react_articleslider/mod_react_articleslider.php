<?php
defined('_JEXEC') or die;

// Load React app
require JModuleHelper::getLayoutPath('mod_react_articleslider');
