<?php
defined('_JEXEC') or die;
?>

<div id="react-article-slider"></div>

<!-- Load React bundle -->
<script src="<?php echo JUri::base(); ?>modules/mod_react_articleslider/react-app/build/static/js/main.db5c4d10.js"></script>
<link rel="stylesheet" href="<?php echo JUri::base(); ?>modules/mod_react_articleslider/react-app/build/static/css/main.05c0c84a.css">
